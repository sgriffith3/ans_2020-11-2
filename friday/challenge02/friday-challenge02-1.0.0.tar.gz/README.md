# Ansible Collection - friday.challenge02

Documentation for the collection.
